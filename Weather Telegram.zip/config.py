open_weather_token = '88c9621abad402d29f54147610c7a01c'
tg_bot_token = "6850936434:AAGJq86qyA2poyMT2zoflgr7KYON2bbpLUY"